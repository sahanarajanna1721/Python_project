names = ['apple', 'google', 'yahoo', 'facebook', 'yelp', 'flipkart', 'gmail', 'instagram', 'microsoft']

items = [ ]

for name in names:
    if len(name) % 2 == 0:
        items.append(name)
    else:
        items.append(name[::-1])

# alternate method
def spam(name):
    if len(name) % 2 == 0:
        return name
    else:
        return name[::-1]

__items = [ spam(name)  for name in names ]

# using comprehension
_items = [ name  if len(name) % 2 == 0  else name[::-1] for name in names ]


a = [1, 2, 3, 4]
b = [5, 6, 7, 8]
c = [ ]

for n1, n2 in zip(a, b):
    c.append(n1 + n2)

# using comprehension
_c = [  n1 + n2  for n1, n2 in zip(a, b) ]

matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

flattened_matrix = [ ]

for item in matrix:  # iterating over outer list
    for _item in item:      # iterating over inner list
        flattened_matrix.append(_item)

# using comprehension

_flattened_matrix = [_item for item in matrix for _item in item ]

letters = "ABCDEFGH"
numbers = [0, 1, 2, 3, 4, 5, 6, 7]

# [A0, B1, C2, D3, ]

result = [ ]

for item1, item2 in zip(letters, numbers):
    result.append(f"{item1}{item2}")

# using list comprehension
_result = [ f"{item1}{item2}" for item1, item2 in zip(letters, numbers) ]


data = ['hello', 12, 1.2, 'world', True, 'python']

items = [ ]

for item in data:
    # if the item that i got, if it is a string, just reverse it and 
    # append it to the list, otherwise, append it as is
    if isinstance(item, str):
        items.append(item[::-1])
    else:
        items.append(item)

# using comprehension
_items = [item[::-1] if isinstance(item, str) else item for item in data ]


sentence = "hello world welcome to python hello hi world welcome to python"

# {"hello": 5, "world": 5, "welcome": 7, "to": 2}

word_len_pair = { }

words = sentence.split()

for word in words:
    word_len_pair[word] = len(word)

# using comprehension
_word_len_pair = { word: len(word) for word in words }


word = "abcdABCD"
# {"a": 97, "b": 98, "c": 99, "d": 100, "A": 65}

letter_ascii_pair = { }

for letter in word:
    letter_ascii_pair[letter] = ord(letter)

# using comprehension
_letter_ascii_pair = { letter: ord(letter) for letter in word }


dial_codes = [
    (86, 'China'),
    (91, 'India'),
    (1, 'United States'),
    (62, 'Indonesia'),
    (55, 'Brazil'),
    (92, 'Pakistan'),
    (880, 'Bangladesh'),
    (234, 'Nigeria'),
    (7, 'Russia'),
    (81, 'Japan')
    ]

# {"China": 86, "India": 91, "United States": 1, "Russia": 7}

country_code_pair = { }

for code, country in dial_codes:
    country_code_pair[country] = code

# using dictionary comprehension
_country_code_pair = {country: code  for code, country in dial_codes }

cities = ['Tokyo',
          'Delhi',
          'Shanghai',
          'Sao Paulo',
          'Mumbai'
          ]
population = ['38,001,000',
              '25,703,168',
              '23,740,778',
              '21,066,245',
              '21,042,538'
              ]

# {"Tokyo": "...", "Delhi": "..."}

city_population_pair = { }

for city, _population in zip(cities, population):
    city_population_pair[city] = _population

# using comprehension

_city_population_pair = {  city: _population for city, _population in zip(cities, population)  }

buildings = { 'burj khalifa': 828, 'Shanghai_Tower': 632, 'Abraj_Al_Bait_Clock Tower': 601, 'Ping_An_Finance_Centre_Shenzhen': 599, 'Lotte World Tower': 554.5, 'World Trade Center': 541.3 }

buildings_height_pair = { }

for building, height in buildings.items():
    buildings_height_pair[building] = height * 3.28

# using dictionary comprehension
_buildings_height_pair = { building: height * 3.28 for building, height in buildings.items() }




prices = { 'ACME': 45.23, 'AAPL': 612.78, 'IBM': 205.55, 'HPQ': 37.20, 'FB': 10.75 }


more_200 = { }

for name, price in prices.items():
    if price > 200:
        more_200[name] = price

# using comprehension
_more_200 = {  name: price  for name, price in prices.items() if price > 200 }

