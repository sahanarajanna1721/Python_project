# functions

# this is function defnition
# generally functions are written for code reuseability and maintainability
def greeting():
    print("hello world")
    print("this is the body of the function!!!!")
    print("hello function")

# below function returns a string
def greet():
    print("hi there")
    return "hello world"

# arguments or parameter
# def and return are built-in keywords 
def _greet(name):
    return f"hello {name}"

# below function takes two inputs (numbers) and returns the sum of two numbers
def add(a, b):
    c = a + b
    return c

# name is an optional argument
# function with some default value to the name argument (or function with optional arguments)
# if you pass any name while calling the function, it take the value
# that you have passed, else, it will take the default value "world"
def greet(name="world"):
    return f"hello {name}"

def add(a=0, b=0):
    return a + b

def greeting(name, age, pay):
    return f"hello {name} you are {age} years of age and you get ${pay}"

def greeting(name, age=26, pay=1000):
    return f"hello {name} you are {age} years of age and you get ${pay}"


def greet(name, debug=False):
    if debug:
        print("you called greet function")
    return f"hello {name}"

# the args comming after * is mandatory keyword only arguments
def greeting(name, *, age, pay):
    return f"hello {name} you are {age} years of age and you get ${pay}"


# this func does not accept any positional arguments
# all three args are mandatorily keyword only arguments
def greeting(*, name, age, pay):
    return f"hello {name} you are {age} years of age and you get ${pay}"

# the arguments before forward slash "/" are mandatorily positionaly only
def greeting(name, /, *, age, pay):
    return f"hello {name} you are {age} years of age and you get ${pay}"

# name is positional only argument
# age and pay could be passed as either as positional or keyword args
def greeting(name, /, age, pay):
    return f"hello {name} you are {age} years of age and you get ${pay}"

# reverse and debug are keyword ONLY args
def greet(name, *, reverse=False, debug=False):
    if debug:   # if debug == True
        print("you called greet function")
    if reverse:   # if reverse == True
        return f"hello {name[::-1]}"
    return f"hello {name}"

# name is positional ONLY args, "reverse" and "debug" are keyword ONLY args
def greet(name, /, *, reverse=False, debug=False):
    if debug:   # if debug == True
        print("you called greet function")
    if reverse:   # if reverse == True
        return f"hello {name[::-1]}"
    return f"hello {name}"

# this func takes variable number of positional arguments
# 0 - N
# * is used to collect excess arguments
# all the positional arguments gets collected inside the tuple
def add(*some_numbers):
    total = 0
    for number in some_numbers:
        total = total + number
    return total


def greet(*names):
    # iterating over a tuple (the name of the tuple is "names")
    for name in names:
        print(f"hello {name}")
        
def func(a, *some_thing):
    print(a)
    print(some_thing)

# some_func can take variable number of keyword arguments
def some_func(**info):
    print(info)

# "func" is capable of taking variable number of positional as well as variable
# number of keyword arguments
def func(*some_things, **some_other_things):
    print(some_things)
    print(some_other_things)

def func(*args, **kwargs):
    print(args)
    print(kwargs)

def greet(name, **info):
    print(f"hello {name} welcome")
    print("*" * 10)
    print(info)
    print("*" * 10)
    for key, value in info.items():
        print(f"{key} and {value}")


#data = ("steve", 26)
#my_data = ['steve', 26, 1000]
#
#def greeting(name, age, pay):
#    return f"hello {name} you are {age} years of age and you get ${pay}"

# indexing the tuple, pulling out each item of the tuple
# passing each item as 3 separate positional arguments
#result1 = greeting(data[0], data[1], data[2])  # greeting("steve", 26, 1000)
#print(result1)

# tuple unpacking
#name, age, pay = data

#result2 = greeting(name, age, pay)
#print(result2)

#result3 = greeting(my_data[0], my_data[1], my_data[2])
#print(result3)

#_name, _age, _pay = my_data

#result4 = greeting(_name, _age, _pay)
#print(result4)

data = ("steve", 26)
t = ()

numbers = (10, 20, 30)

_numbers = {"a": 10, "b": 20, "c": 30}

def greeting(name, age):
    return f"hello {name} you are {age} years of age"

def greet():
    return "hello"

def add(a, b, c):
    return a + b + c

# greeting("steve", 26, 1000)
result5 = greeting(*data)  # calling a func greeting("steve", 26, 1000)

# greet("steve") unpacking an empty tuple
result6 = greet(*t)

total = add(1, 2, 3)
total = add(*numbers)

_numbers = {"a": 10, "b": 20, "c": 30}

# add(10, 20, 30)
total = add(_numbers['a'], _numbers['b'], _numbers['c'])

# this is called dictionary unpacking
total = add(**_numbers)   # add(a=10, b=20, c=30)


def add(a, b, c, d, e, f):
    return a + b + c + d + e + f

l1 = (1, 2, 3)
# l2 = [4, 5, 6]
d = {"d": 4, "e": 5, "f": 6}

#r1 = add(l1[0], l1[1], l1[2], l2[0], l2[1], l2[2])
#
#n1, n2, n3 = l1
#n4, n5, n6 = l2
#
#r2 = add(n1, n2, n3, n4, n5, n6)

r3 = add(*l1, **d) # add(1, 2, 3, d=4, e=5, f=6)

# wrong!!!
# add(**d, *l1)   # add(d=4, e=5, f=6, 1, 2, 3)

t = (1, 2, 3)
d = {"a": 1, "b": 2, "c": 3}

def add(a, b, c):
    return a + b + c

add(*t)  # add(1, 2, 3)
add(**d) # add(a=1, b=2, c=3)

def dummy(*args, **kwargs):
    print(args)
    print(kwargs)

def add(a, b):
    return a + b

def qudratic_equation(a, b):
    return a ** 2 + b ** 2 + 2 * a * b

def get_last_letter(some_string):
    return some_string[-1]

# lambda functions or anonymous-functions
add = lambda a, b: a + b

qudratic_equation = lambda a, b: a ** 2 + b ** 2 + 2 * a * b

get_last_letter = lambda some_string: some_string[-1]


def greet():
    return "hello world"

def add(a, b):
    return a + b

def sub(a, b):
    return a - b

def mul(a, b):
    return a * b

