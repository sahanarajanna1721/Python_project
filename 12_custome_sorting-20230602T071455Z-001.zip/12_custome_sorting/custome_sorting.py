# custom sorting
names = ['apple', 'google', 'yahoo', 'amazon', 'facebook', 'instagram', 'microsoft', 'zomato']

points = {'a': 4, 'b': 3, 'c': 2, 'd': 1}

prices = {'ACME': 45.23, 'AAPL': 612.78, 'IBM': 205.55, 'HPQ': 37.20, 'FB': 10.75 }

numbers = (1, 2, 6, 7, 10, 3, 4, 5)

word = "hello"

temperatures = [('Bangalore', 25), ('Delhi', 35), ('Chennai', 37), ('Mumbai', 32)]

def get_len(some_string):
    return len(some_string)

# sorting based on length of each item if the list
s_names = sorted(names, key=get_len)

# using lambda func (defining the function inline)
s_names = sorted(names, key=lambda some_string: len(some_string))

items = ['bv', 'aw', 'dt', 'cu']

def get_last_letter(some_string):
    return some_string[-1]

by_last_letter = sorted(items, key=get_last_letter)

by_last_letter = sorted(items, key=lambda some_string: some_string[-1])


def get_temperature(some_tuple):
    return some_tuple[-1]

by_temp = sorted(temperatures, key=get_temperature)

by_temp = sorted(temperatures, key=lambda some_tuple: some_tuple[-1])

points = {'a': 4, 'b': 3, 'c': 2, 'd': 1}
# {"d": 1, "c": 2, "b": 3, "a": 4}

# list of tuples (each tuple is a key,value pair)
key_value_pair = points.items()

def get_value(some_tuple):
    return some_tuple[-1]

by_values = sorted(key_value_pair, key=get_value)

by_values = sorted(key_value_pair, key=lambda some_tuple: some_tuple[-1])
# soln.1
_by_values = dict(by_values)

# soln.2
d = { }
# making a dict using list of tuples
for key, value in by_values:
    d[key] = value


prices = {'ACME': 45.23, 'AAPL': 612.78, 'IBM': 205.55, 'HPQ': 37.20, 'FB': 10.75 }

# get a list of tuples (each tuple is a pair of company name and its corresponding share value using items() method)
info = prices.items()

# below function takes a tuple and returns last item of the tuple
def get_share_price(some_tuple):
    return some_tuple[-1]

# pass the list of tuples to sorted function, and provide the reference of the function "get_share_price" to key keyword argument
by_price = sorted(info, key=get_share_price)

by_price = sorted(info, key=lambda some_tuple: some_tuple[-1])

portfolio = [
                {'name': 'IBM', 'shares': 100, 'price': 91.1},
                {'name': 'AAPL', 'shares': 50, 'price': 543.22},
                {'name': 'FB', 'shares': 200, 'price': 21.09},
                {'name': 'HPQ', 'shares': 35, 'price': 31.75},
                {'name': 'YHOO', 'shares': 45, 'price': 16.35},
                {'name': 'ACME', 'shares': 75, 'price': 115.65}
            ]

def get_name(some_dict):
    return some_dict['name']

def get_shares(some_dict):
    return some_dict['shares']

def get_price(some_dict):
    return some_dict['price']

by_name = sorted(portfolio, key=get_name)
by_name = sorted(portfolio, key=lambda some_dict: some_dict['name'])

by_shares = sorted(portfolio, key=get_shares)
by_shares = sorted(portfolio, key=lambda some_dict: some_dict['shares'])

by_price = sorted(portfolio, key=get_price)
by_price = sorted(portfolio, key=lambda some_dict: some_dict['price'])

students = [
    {"name": "john", "grade": "A", "age": 26},
    {"name": "jane", "grade": "B", "age": 28},
    {"name": "dave", "grade": "B", "age": 22}
]

#students = [
#        ("john", "A", 26),
#        ("jane", "B", 28),
#        ("dave", "B", 22)
#]

def get_student_name(some_dict):
    return some_dict['name']

def get_student_grade(some_dict):
    return some_dict['grade']

def get_student_age(some_dict):
    return some_dict['age']

by_name = sorted(students, key=get_student_name)

by_grade = sorted(students, key=get_student_grade)

by_age = sorted(students, key=get_student_age)

names = ['steve jobs', 'bill gates', 'john doe', 'tim cook', 'laura turner', 'alex martin']

def get_last_name(full_name):
     words = full_name.split()
     fname, lname = words
     return lname

by_lname = sorted(names, key=get_last_name)

sentence = "This is a Programming language and Programming is fun"

words = sentence.split()

# longest substring
word_len_pair = { word: len(word) for word in words }

# sort the dictionary
info = word_len_pair.items()

def get_word_len(some_tuple):
    return some_tuple[-1]

by_len = sorted(info, key=get_word_len)

# longest non-repeating substring
words = sentence.split()

word_len_pair = { word: len(word) for word in words if words.count(word) == 1}

info = word_len_pair.items()

by_len_non_repeated = sorted(info, key=get_word_len)


sentence = "hi hello hi hello world hi universe hi world hello world hi world"

words = sentence.split()

word_count_pair = { word: words.count(word) for word in words }

info = word_count_pair.items()

def get_count(some_tuple):
    return some_tuple[-1]

by_count = sorted(info, key=get_count)

sentence = 'hi hello hi hi hiiiiii'

letter_count_pair = { letter: sentence.count(letter)  for letter in sentence }

info = letter_count_pair.items()

def get_count(some_tuple):
    return some_tuple[-1]


by_count = sorted(info, key=get_count)

